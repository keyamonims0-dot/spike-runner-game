Spike Runner — Tesla Roadster-inspired car update

Replace the existing index.html in your GitHub repository with this updated index.html:
1. Open the repository and select index.html.
2. Tap the pencil (Edit this file) if available, or use Add file > Upload files to upload this replacement.
3. If uploading, replace the existing index.html and commit changes.
4. Wait a minute or two, then refresh your GitHub Pages game site.

This changes the car drawing to a red, sleek Roadster-inspired sports car. It is a stylized game graphic, not an official Tesla asset.
